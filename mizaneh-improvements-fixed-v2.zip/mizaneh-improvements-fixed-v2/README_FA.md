# بستهٔ بهبود میزانه

این بسته برای شاخهٔ `main` مخزن میزانه و به‌طور مشخص commit زیر آماده شده است:

`53ceb9fed1c90b4ea69feab9be460ad161484928`

نصب‌کننده روی ساختار فعلی fail-fast است: ابتدا تمام قطعه‌های مورد انتظار را در حافظه بررسی می‌کند و فقط پس از موفقیت همهٔ بررسی‌ها فایل‌ها را می‌نویسد. اجرای دوبارهٔ آن نیز بی‌خطر است.

## یادداشت نسخهٔ اصلاح‌شده

این نسخه جایگزین ZIP قبلی است. import نوع `AdjustmentProposal` در `DietPlanner.tsx` حفظ می‌شود، چون تابع `handleAdjustmentDecision` هنوز از آن استفاده می‌کند. از نسخهٔ قدیمی استفاده نکنید.

## اعمال تغییرات

```bash
git clone https://github.com/Hhhkarimi/mizaneh.git
cd mizaneh
git checkout -b refactor/release-hardening
node /path/to/mizaneh-improvements/apply-improvements.mjs .
npm ci
npm run verify
npm audit --omit=dev --audit-level=high
git status
git add .
git commit -m "refactor: harden release pipeline and planner architecture"
git push -u origin refactor/release-hardening
```

اگر `main` بعد از commit بالا تغییر کرده باشد، نصب‌کننده در صورت ناسازگاری متوقف می‌شود و چیزی را حدس نمی‌زند. در آن حالت ابتدا تغییرات جدید مخزن را review کنید.

## تغییرات اصلی

- GitHub Actions برای lint، تست همراه coverage، کنترل معماری، کنترل تاریخ سیاست‌ها، build و audit.
- استخراج state و refهای React از `DietPlanner.tsx` به `hooks/usePlannerState.ts`.
- استخراج سازندهٔ سند برنامه، تولید امن برنامه و SVG برند.
- حذف خودکار داده‌های سلامت محلی پس از ۱۸۰ روز و پاک‌کردن payloadهای خراب.
- guardrail برای جلوگیری از بزرگ‌شدن دوبارهٔ `DietPlanner` و وابستگی `lib` به UI.
- شکست CI در صورت انقضای سیاست محاسباتی فعال؛ سیاست legacy فقط هشدار می‌دهد.
- headerهای دفاعی بیشتر و جلوگیری از cache شدن service worker.

پس از اولین push، در تنظیمات GitHub برای شاخهٔ `main`، check با نام `Quality gate / verify` را الزامی کنید.


## اصلاح نسخهٔ v2

نصب‌کننده اکنون تفاوت‌های بی‌خطر در بلوک cleanup تابع `loadWorkspace` را تحمل می‌کند و در صورت وجود cleanup قبلی، آن را دوباره‌نویسی نمی‌کند.
