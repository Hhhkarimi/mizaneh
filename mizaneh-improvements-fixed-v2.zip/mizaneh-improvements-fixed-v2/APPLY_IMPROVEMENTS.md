# Applying the Mizaneh improvement bundle

Prerequisite: a clean checkout of `https://github.com/Hhhkarimi/mizaneh`. The bundle was prepared against commit `53ceb9fed1c90b4ea69feab9be460ad161484928`.

```bash
git checkout -b refactor/release-hardening
node /path/to/mizaneh-improvements/apply-improvements.mjs /path/to/your/mizaneh
cd /path/to/your/mizaneh
npm ci
npm run verify
npm audit --omit=dev --audit-level=high
git status
git add .
git commit -m "refactor: harden release pipeline and planner architecture"
git push -u origin refactor/release-hardening
```

The installer is intentionally fail-fast and preflights all source transformations before writing them. If an expected source fragment is not found, it stops instead of guessing against a different revision. Run it on the current `main` version or review the reported fragment manually.

After pushing, protect `main` and require the **Quality gate / verify** check before merge.
