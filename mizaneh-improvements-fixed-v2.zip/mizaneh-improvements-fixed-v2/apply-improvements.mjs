#!/usr/bin/env node
import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const bundleRoot = path.dirname(fileURLToPath(import.meta.url));
const targetRoot = path.resolve(process.argv[2] ?? process.cwd());

async function read(relativePath) {
  return readFile(path.join(targetRoot, relativePath), "utf8");
}

async function write(relativePath, content) {
  const fullPath = path.join(targetRoot, relativePath);
  await mkdir(path.dirname(fullPath), { recursive: true });
  await writeFile(fullPath, content);
}

function replaceOnce(source, before, after, label) {
  if (after.length > 0 && source.includes(after)) return source;
  const first = source.indexOf(before);
  if (first === -1 && after.length === 0) return source;
  if (first === -1) throw new Error(`Could not find expected source fragment: ${label}`);
  if (source.indexOf(before, first + before.length) !== -1) {
    throw new Error(`Expected a unique source fragment but found more than one: ${label}`);
  }
  return source.slice(0, first) + after + source.slice(first + before.length);
}

async function patchDietPlanner() {
  let source = await read("app/DietPlanner.tsx");
  source = replaceOnce(
    source,
    'import { FormEvent, useMemo, useRef, useState } from "react";',
    'import { FormEvent, useMemo } from "react";',
    "React state imports",
  );

  source = replaceOnce(source, "  Metrics,\n", "", "unused Metrics type import");
  source = replaceOnce(source, "  WeightMeasurement,\n", "", "unused WeightMeasurement type import");
  source = replaceOnce(source, "  defaultForm,\n", "", "unused defaultForm import");
  source = replaceOnce(
    source,
    'import { buildWeeklyPlan, applySubstitution, getMeal, getSubstituteOptions } from "@/lib/plan/build";',
    'import { applySubstitution, getMeal, getSubstituteOptions } from "@/lib/plan/build";',
    "unused buildWeeklyPlan import",
  );
  source = replaceOnce(source, "  type PlanHistory,\n", "", "unused PlanHistory type import");

  const importAnchor = 'import { resolveClinicalSources } from "@/lib/clinical/source-registry";';
  const newImports = `${importAnchor}\nimport { BrandMark } from "@/components/BrandMark";\nimport { createPlanDocument } from "@/lib/planner/createPlanDocument";\nimport { safeBuildWeeklyPlan } from "@/lib/planner/safeBuildWeeklyPlan";\nimport { usePlannerState } from "@/hooks/usePlannerState";`;
  source = replaceOnce(source, importAnchor, newImports, "planner extraction imports");

  source = replaceOnce(
    source,
`function safeBuildWeeklyPlan(form: PlannerForm, metrics: Metrics, mode: PlanMode, variationSeed: number): { plan: DayPlan[]; error: string } {
  try {
    return { plan: ensurePlanIdentity(buildWeeklyPlan(form, metrics, mode, variationSeed)), error: "" };
  } catch (cause) {
    return {
      plan: [],
      error: cause instanceof Error
        ? cause.message
        : "برای محدودیت‌های ثبت‌شده برنامهٔ سازگار ساخته نشد. مواد یا محدودیت‌ها را بازبینی کنید.",
    };
  }
}
`,
    "",
    "inline safeBuildWeeklyPlan",
  );

  source = replaceOnce(
    source,
`function BrandMark({ className = "" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 64 64"
      role="img"
      aria-label="نشان میزانه"
    >
      <path
        d="M10 34h44c-1.8 12.7-10.5 20-22 20S11.8 46.7 10 34Z"
        fill="currentColor"
      />
      <path
        d="M17 34c2-8.2 7-12.3 15-12.3S45 25.8 47 34"
        fill="none"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="5"
      />
      <path
        d="M33.8 20.7C34.2 11.7 40.2 7 50 8.3c-.9 8.4-6.2 12.6-16.2 12.4Z"
        fill="#9dd24b"
      />
      <path
        d="M29.8 20.5c-1.1-6.7-5.4-10.1-12.9-10.3.2 6.8 4.5 10.3 12.9 10.3Z"
        fill="#ff6b55"
      />
      <path d="M18 58h28" stroke="currentColor" strokeLinecap="round" strokeWidth="4" />
    </svg>
  );
}
`,
    "",
    "inline BrandMark",
  );

  source = replaceOnce(
    source,
`  const [form, setForm] = useState<PlannerForm>(defaultForm);
  const [step, setStep] = useState(1);
  const [error, setError] = useState("");
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [submittedForm, setSubmittedForm] = useState<PlannerForm | null>(null);
  const [planMode, setPlanMode] = useState<PlanMode>("variety");
  const [variationSeed, setVariationSeed] = useState(1);
  const [activeDay, setActiveDay] = useState(0);
  const [copyState, setCopyState] = useState<"idle" | "done">("idle");
  const [planHistory, setPlanHistory] = useState<PlanHistory | null>(null);
  const [baselinePlan, setBaselinePlan] = useState<DayPlan[]>([]);
  const [archivedPlans, setArchivedPlans] = useState<PlanDocument[]>([]);
  const [activePlanId, setActivePlanId] = useState(() => \`plan-\${Date.now()}\`);
  const [activePlanCreatedAt, setActivePlanCreatedAt] = useState(() => new Date().toISOString());
  const [pendingGoal, setPendingGoal] = useState<{ goal: Goal; source: "guided" | "direct" } | null>(null);
  const [liveAnnouncement, setLiveAnnouncement] = useState("");
  const [measurements, setMeasurements] = useState<WeightMeasurement[]>([]);
  const [adjustmentProposal, setAdjustmentProposal] = useState<AdjustmentProposal | null>(null);
  const [lastAdjustmentAt, setLastAdjustmentAt] = useState<string | undefined>(undefined);
  const [startingTargetCalories, setStartingTargetCalories] = useState<number | null>(null);
  const [comparisonPlanId, setComparisonPlanId] = useState<string | null>(null);
  const resultsRef = useRef<HTMLElement>(null);
`,
`  const {
    form, setForm, step, setStep, error, setError, metrics, setMetrics,
    submittedForm, setSubmittedForm, planMode, setPlanMode,
    variationSeed, setVariationSeed, activeDay, setActiveDay, copyState, setCopyState,
    planHistory, setPlanHistory, baselinePlan, setBaselinePlan,
    archivedPlans, setArchivedPlans, activePlanId, setActivePlanId,
    activePlanCreatedAt, setActivePlanCreatedAt, pendingGoal, setPendingGoal,
    liveAnnouncement, setLiveAnnouncement, measurements, setMeasurements,
    adjustmentProposal, setAdjustmentProposal, lastAdjustmentAt, setLastAdjustmentAt,
    startingTargetCalories, setStartingTargetCalories, comparisonPlanId, setComparisonPlanId,
    substitutionTarget, setSubstitutionTarget, savedAt, setSavedAt,
    justSaved, setJustSaved, resultsRef,
  } = usePlannerState();
`,
    "planner state declarations",
  );

  source = replaceOnce(
    source,
`  const [substitutionTarget, setSubstitutionTarget] = useState<{
    slot: MealSlot;
    occurrence: number;
  } | null>(null);
`,
    "",
    "substitution state",
  );
  source = replaceOnce(
    source,
`  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState(false);
`,
    "",
    "save state",
  );

  source = replaceOnce(
    source,
`  function currentPlanDocument(name = "برنامهٔ فعال", id = activePlanId, parentPlanId = archivedPlans.at(-1)?.id ?? null): PlanDocument | null {
    if (!metrics || !submittedForm || displayedPlan.length === 0) return null;
    const now = new Date().toISOString();
    return {
      schemaVersion: 2,
      id,
      parentPlanId,
      name,
      goal: submittedForm.goal,
      form: structuredClone(submittedForm),
      safetyScreen: screenSafety(submittedForm),
      calculation: structuredClone(metrics),
      startingTargetCalories: startingTargetCalories ?? metrics.targetCalories,
      planMode,
      variationSeed,
      days: structuredClone(displayedPlan),
      versions: archivedPlans.map((plan) => ({ id: plan.id, name: plan.name, goal: plan.goal, createdAt: plan.createdAt, parentPlanId: plan.parentPlanId })),
      measurements: structuredClone(measurements),
      adjustmentProposals: adjustmentProposal ? [structuredClone(adjustmentProposal)] : [],
      lastAdjustmentAt,
      createdAt: id === activePlanId ? activePlanCreatedAt : now,
      updatedAt: now,
      legacy: metrics.policy.evidenceCertainty === "legacy",
    };
  }
`,
`  function currentPlanDocument(name = "برنامهٔ فعال", id = activePlanId, parentPlanId = archivedPlans.at(-1)?.id ?? null): PlanDocument | null {
    return createPlanDocument({
      metrics,
      submittedForm,
      displayedPlan,
      name,
      id,
      parentPlanId,
      activePlanId,
      activePlanCreatedAt,
      archivedPlans,
      startingTargetCalories,
      planMode,
      variationSeed,
      measurements,
      adjustmentProposal,
      lastAdjustmentAt,
    });
  }
`,
    "plan document builder",
  );

  if (/\b(?:useState|useRef)\b/.test(source) || source.includes("function BrandMark") || source.includes("function safeBuildWeeklyPlan")) {
    throw new Error("DietPlanner extraction preflight failed; no source files were written.");
  }
  if (source.includes("handleAdjustmentDecision(proposal: AdjustmentProposal") && !source.includes("  AdjustmentProposal,\n")) {
    throw new Error("DietPlanner still uses AdjustmentProposal but its type import is missing.");
  }
  return source;
}

async function patchPackageJson() {
  const packagePath = path.join(targetRoot, "package.json");
  const packageJson = JSON.parse(await readFile(packagePath, "utf8"));
  packageJson.scripts = {
    ...packageJson.scripts,
    "check:architecture": "node scripts/check-architecture.mjs",
    "check:policy-review": "node scripts/check-policy-review.mjs",
    verify: "npm run lint && npm run test:coverage && npm run check:architecture && npm run check:policy-review && npm run build",
  };
  return `${JSON.stringify(packageJson, null, 2)}\n`;
}

async function patchWorkspaceStorage() {
  let source = await read("lib/storage/workspace.ts");
  const anchor = 'import type { StoredSession } from "@/lib/storage/session";';
  source = replaceOnce(
    source,
    anchor,
    `${anchor}\nimport { isPersistedDataExpired } from "@/lib/storage/retention";`,
    "workspace retention import",
  );
  source = replaceOnce(
    source,
`    const raw = target.getItem(WORKSPACE_KEY);
    if (!raw || raw.length > MAX_PERSISTED_BYTES) return null;
    return validateWorkspace(JSON.parse(raw));
`,
`    const raw = target.getItem(WORKSPACE_KEY);
    if (!raw) return null;
    if (raw.length > MAX_PERSISTED_BYTES) {
      target.removeItem(WORKSPACE_KEY);
      return null;
    }
    const workspace = validateWorkspace(JSON.parse(raw));
    if (!workspace || isPersistedDataExpired(workspace.savedAt)) {
      target.removeItem(WORKSPACE_KEY);
      return null;
    }
    return workspace;
`,
    "workspace expiration",
  );
  source = replaceOnce(
    source,
`export function hasWorkspace(): boolean {
  const target = storage();
  if (!target) return false;
  try {
    return target.getItem(WORKSPACE_KEY) !== null;
  } catch {
    return false;
  }
}
`,
`export function hasWorkspace(): boolean {
  return loadWorkspace() !== null;
}
`,
    "workspace presence validation",
  );
  const loadWorkspaceStart = source.indexOf("export function loadWorkspace(");
  const clearWorkspaceStart = source.indexOf("export function clearWorkspace", loadWorkspaceStart);
  if (loadWorkspaceStart === -1 || clearWorkspaceStart === -1) {
    throw new Error("Could not locate loadWorkspace/clearWorkspace boundary.");
  }
  let loadWorkspaceBlock = source.slice(loadWorkspaceStart, clearWorkspaceStart);
  if (!loadWorkspaceBlock.includes("target.removeItem(WORKSPACE_KEY)")) {
    const plainCatch = `  } catch {\n    return null;\n  }\n}\n`;
    const cleanupCatch = `  } catch {\n    try { target.removeItem(WORKSPACE_KEY); } catch { /* best-effort cleanup */ }\n    return null;\n  }\n}\n`;
    if (!loadWorkspaceBlock.endsWith(plainCatch)) {
      throw new Error("Could not safely patch malformed workspace cleanup.");
    }
    loadWorkspaceBlock = loadWorkspaceBlock.slice(0, -plainCatch.length) + cleanupCatch;
    source = source.slice(0, loadWorkspaceStart) + loadWorkspaceBlock + source.slice(clearWorkspaceStart);
  }
  return source;
}

async function patchLegacySessionStorage() {
  let source = await read("lib/storage/session.ts");
  const anchor = 'import type { DayPlan, PlanMode, PlannerForm } from "@/lib/types";';
  source = replaceOnce(
    source,
    anchor,
    `${anchor}\nimport { isPersistedDataExpired } from "@/lib/storage/retention";`,
    "session retention import",
  );
  source = replaceOnce(
    source,
`    const form = normalizeForm(parsed.form);
    if (
`,
`    const savedAt = typeof parsed.savedAt === "string" ? parsed.savedAt : "";
    if (isPersistedDataExpired(savedAt)) {
      storage.removeItem(STORAGE_KEY);
      return null;
    }
    const form = normalizeForm(parsed.form);
    if (
`,
    "legacy session expiration",
  );
  source = replaceOnce(
    source,
`      savedAt: typeof parsed.savedAt === "string" ? parsed.savedAt : new Date().toISOString(),
`,
`      savedAt,
`,
    "validated legacy savedAt",
  );
  source = replaceOnce(
    source,
`export function hasSavedSession(): boolean {
  const storage = getStorage();
  if (!storage) return false;
  try {
    return storage.getItem(STORAGE_KEY) !== null;
  } catch {
    return false;
  }
}
`,
`export function hasSavedSession(): boolean {
  return loadSession() !== null;
}
`,
    "legacy session presence validation",
  );
  source = replaceOnce(
    source,
`  } catch {
    return null;
  }
}
export function clearSession`,
`  } catch {
    try { storage.removeItem(STORAGE_KEY); } catch { /* best-effort cleanup */ }
    return null;
  }
}
export function clearSession`,
    "malformed legacy session cleanup",
  );
  return source;
}

async function patchNextConfig() {
  let source = await read("next.config.ts");
  source = replaceOnce(
    source,
`  { key: "X-Permitted-Cross-Domain-Policies", value: "none" },
`,
`  { key: "X-Permitted-Cross-Domain-Policies", value: "none" },
  { key: "X-Download-Options", value: "noopen" },
  { key: "Origin-Agent-Cluster", value: "?1" },
`,
    "defensive response headers",
  );
  source = replaceOnce(
    source,
`    return [
      {
        source: "/(.*)",
        headers: securityHeaders,
      },
    ];
`,
`    return [
      {
        source: "/sw.js",
        headers: [
          { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
          { key: "Service-Worker-Allowed", value: "/" },
        ],
      },
      {
        source: "/(.*)",
        headers: securityHeaders,
      },
    ];
`,
    "service worker headers",
  );
  return source;
}

async function patchReadme() {
  const marker = "## سخت‌گیری انتشار و نگه‌داری داده";
  let source = await read("README.md");
  if (source.includes(marker)) return source;
  source += `\n\n${marker}\n\nبرای اجرای یکپارچهٔ lint، تست، کنترل معماری، تاریخ بازبینی سیاست‌های فعال و build:\n\n\`\`\`bash\nnpm run verify\n\`\`\`\n\nداده‌های سلامت فقط پس از ذخیرهٔ صریح کاربر در مرورگر نگه‌داری می‌شوند و پس از ۱۸۰ روز بدون ذخیرهٔ مجدد، هنگام خواندن به‌صورت خودکار حذف می‌شوند.\n`;
  return source;
}

async function copyPayload() {
  await cp(path.join(bundleRoot, "payload"), targetRoot, { recursive: true, force: true });
}

async function assertRepository() {
  const packageJson = JSON.parse(await read("package.json"));
  if (packageJson.name !== "mizaneh-nutrition-planner") {
    throw new Error(`Target does not look like Mizaneh: ${targetRoot}`);
  }
}

try {
  await assertRepository();

  // Preflight every source transformation before writing anything. This keeps
  // a revision mismatch from leaving a partially modified checkout.
  const outputs = new Map([
    ["app/DietPlanner.tsx", await patchDietPlanner()],
    ["package.json", await patchPackageJson()],
    ["lib/storage/workspace.ts", await patchWorkspaceStorage()],
    ["lib/storage/session.ts", await patchLegacySessionStorage()],
    ["next.config.ts", await patchNextConfig()],
    ["README.md", await patchReadme()],
  ]);

  for (const [relativePath, content] of outputs) await write(relativePath, content);
  await copyPayload();
  console.log(`Mizaneh improvements applied to ${targetRoot}`);
  console.log("Next: npm ci && npm run verify && npm audit --omit=dev --audit-level=high");
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
}
