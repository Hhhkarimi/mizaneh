# Validation performed on the bundle

Validated on 2026-08-06 against the source shape at commit `53ceb9fed1c90b4ea69feab9be460ad161484928`.

Completed checks:

- JavaScript syntax checks for the installer and both CI guard scripts.
- Installer application against an exact-fragment fixture representing the target files.
- A second installer run against the already-modified fixture to verify idempotence.
- Architecture guard execution after installation.
- Policy-review guard execution with the current active and legacy dates.
- TypeScript/TSX syntax and local type-flow check for all new payload files using strict compiler settings and module stubs.
- SHA-256 manifest generation for every distributed file.

Not completed in this environment:

- A full `npm ci`, repository lint, complete Vitest suite, Next.js production build or dependency audit on a materialized checkout of the repository.

Those checks are intentionally required by `npm run verify` and the included GitHub Actions workflow. Run them before merging; do not bypass the quality gate.
