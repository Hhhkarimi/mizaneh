# Mizaneh improvement bundle

Implemented changes:

1. Mandatory GitHub Actions quality gate.
2. Exact Node version through `.nvmrc`.
3. Architecture checks preventing `DietPlanner.tsx` growth and presentation imports from `lib`.
4. Active clinical-policy review-date gate; expired legacy policy stays warning-only and frozen.
5. 180-day expiration and automatic deletion for opt-in local workspace/session health data.
6. Extraction of planner state/ref ownership into `hooks`, plus safe plan generation, plan-document creation and brand SVG from `DietPlanner.tsx`.
7. Service-worker cache headers and two additional defensive response headers.
8. New tests for local-data expiration.

No nutrition constants, clinical thresholds, food data or user-visible planning rules are changed by this bundle.
